export const environment = {
    production:true,
    apiUrl:'https://expense-tracker-t3cs.onrender.com/v1/api/',
    adminId: '6558727029c0dacee0900c6a'
};