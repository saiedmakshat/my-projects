export interface ExpenseContent {
    id:string,
    name: string,
    amount: number,
    expense_date: string,
    expense_category: string,
    payment: string,
    comment: string
  }
  