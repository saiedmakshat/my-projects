export interface Color{
    colorId:number,
    colorName:string
}