export interface CarImage{
    imageId:number,
    carId:number,
    imagePath:string,
    date:Date
}