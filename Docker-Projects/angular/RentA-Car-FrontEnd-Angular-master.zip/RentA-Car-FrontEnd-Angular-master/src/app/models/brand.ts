export interface Brand{
    brandId:number,
    brandName:string
}