export interface Customer{
    userId:number;
    companyName:string;
    
   
}