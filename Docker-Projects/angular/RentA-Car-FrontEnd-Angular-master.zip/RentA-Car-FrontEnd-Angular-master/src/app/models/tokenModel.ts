export interface TokenModel{
    token:string;
    expiration:string
}