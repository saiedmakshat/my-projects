import { Car } from "./car";
import { CarImage } from "./carImage";

export interface CarDetail{
    car:Car;
    carImage:CarImage[];
}