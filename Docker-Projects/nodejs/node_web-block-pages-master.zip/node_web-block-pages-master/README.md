# node_web-block-pages

NodeJS application I used along with pfSense and Squid to display a different block page when a website was blocked based on its category
